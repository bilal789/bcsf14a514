package com.linearpractisefirstapp.todotoday;

import android.app.Activity;
import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ArrayAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    protected DBHelper mdbhelper;
    private List<ToDo_Item> list;
    private EditText mytask;
    private MyAdapter adapt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
          setTheme(R.style.AppTheme);
        super.onCreate(savedInstanceState);
        //Launch the layout
        setContentView(R.layout.activity_main);

        //establish references to the ui
        mytask=(EditText) findViewById(R.id.et1);
        //set up the database
        mdbhelper=new DBHelper(this);

        final Button button = (Button) findViewById(R.id.b1);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                addtasknow(v);
            }
        });

        final Button button1 = (Button) findViewById(R.id.b2);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                cleartasks(v);
            }
        });


    }

    //button click event for adding a  task
    public void addtasknow(View view)
    {
      String s=  mytask.getText().toString();
        if(s.isEmpty())
        {
            Toast.makeText(getApplicationContext(),"A todo Task must be entered",Toast.LENGTH_SHORT).show();
        }
        else {
            //buid a new task and add it in the database
            ToDo_Item task = new ToDo_Item(0 , s, 0);
            mdbhelper.addToDoItem(task);
            //clear out the task editview
            mytask.setText("");
            //add a task  set notification of changes

            //add a task and set a notififcation changes
            adapt.add(task);
            adapt.notifyDataSetChanged();

        }
    }

    //button click event for deleting a task
    public void cleartasks(View view)
    {
        mdbhelper.clearAll(list);
        adapt.notifyDataSetChanged();
    }


    //************************adapter******************************************
    private class MyAdapter extends ArrayAdapter<ToDo_Item> {
        Context context;
        List<ToDo_Item> tasklist = new ArrayList<ToDo_Item>();


        public MyAdapter(Context c, int resource, List<ToDo_Item> objects) {
            super(c, resource, objects);
            tasklist = objects;
            context = c;
        }


        //To_do task item view
        //this method defines the to_do item that will placed in the listview
        //the checkbox state is the is_done status of the todo_task and the checkbox text is
        //the todo_item description

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CheckBox isdonechbx = null;
            if (convertView == null) {

                LayoutInflater inflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                convertView=inflater.inflate(R.layout.todo_item,parent,false);
                isdonechbx=(CheckBox)convertView.findViewById(R.id.chkstatus);
                convertView.setTag(isdonechbx);
                isdonechbx.setOnClickListener(new View.OnClickListener()
                {

                    @Override
                    public void onClick(View view) {
                        CheckBox cb=(CheckBox) view;
                        ToDo_Item changeTask=(ToDo_Item) cb.getTag();
                        changeTask.setIs_done(cb.isChecked()== true ? 1 : 0);
                        mdbhelper.updatetask(changeTask);
                    }
                });

            }
            else
            {
                isdonechbx=(CheckBox)convertView.getTag();
            }
            ToDo_Item current=tasklist.get(position);
            isdonechbx.setText(current.getDescription());
            isdonechbx.setChecked(current.getIs_done() == 1 ? true : false);
            isdonechbx.setTag(current);
            return convertView;
        }
    }

@Override
    public boolean onCreateOptionsMenu(Menu menu)
{
    //inflate the menu
    getMenuInflater().inflate(R.menu.manu_main,menu);
    return true;
}
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int id=item.getItemId();
        if(id == R.id.action_settings)
        {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}

