package com.linearpractisefirstapp.todotoday;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Bilal on 1/4/2018.
 */
public class DBHelper extends SQLiteOpenHelper {

    //Define Database and Table

    private static final String DATABASE_NAME="todo_today";
    private static final String DATABASE_TABLE="toDo_Items";

    //defining the column names for table
    private static final String KEY_TASK_ID="_id";
    private static final String KEY_DESCRIPTION="description";
    private static final String KEY_IS_DONE="is_done";

    //column type
    public static final String TYPE_TEXT = " TEXT ";
    public static final String TYPE_INT = " INT ";
    public static final String SEPERATOR = ", ";

    private int taskCount;

    public DBHelper(Context context) {
        super(context,DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String table="CREATE TABLE " + DATABASE_TABLE + " (" + KEY_TASK_ID + TYPE_INT + " AUTO_INCREMENT PRIMARY KEY " + SEPERATOR + KEY_DESCRIPTION + TYPE_TEXT + SEPERATOR + KEY_IS_DONE + TYPE_INT + ") ;";

        db.execSQL(table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

              db.execSQL("DROP TABLE IF EXISTS "+DATABASE_TABLE);

        //create table again
        onCreate(db);
    }
    //DATABASE OPERATIONS: add,edit,delete
    //add new task
    public void addToDoItem(ToDo_Item task)
    {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //add key value pairs

        values.put(KEY_DESCRIPTION, task.getDescription());
        values.put(KEY_IS_DONE, task.getIs_done());
        //insert a row in a database
        db.insert(DATABASE_TABLE, null, values);
                taskCount++;
        db.close();
    }

    public List<ToDo_Item> getallTasks()
    {
        ArrayList<ToDo_Item> itemslist=new ArrayList<ToDo_Item>();
        String selectalltask="select * from "+DATABASE_TABLE ;
        SQLiteDatabase db=this.getWritableDatabase();
        Cursor cursor=db.rawQuery(selectalltask,null);
        //Loop through the to_do tasks

        if(cursor.moveToFirst())
        {
            do{
                ToDo_Item task=new ToDo_Item();
                task.set_id(cursor.getInt(0));
                task.setDescription(cursor.getString(1));
                task.setIs_done(cursor.getInt(2));
                itemslist.add(task);
            }while(cursor.moveToNext());
        }

        return itemslist;
    }
    public void clearAll(List<ToDo_Item> list)
    {
        //get all the tasks and clear them
        list.clear();
        SQLiteDatabase db=this.getWritableDatabase();
        db.delete(DATABASE_TABLE, null, new String[]{});
        db.close();
    }

    public void updatetask(ToDo_Item task)
    {
        //Update Record
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values=new ContentValues();

        values.put(KEY_DESCRIPTION,task.getDescription());
        values.put(KEY_IS_DONE,task.getIs_done());

        db.update(DATABASE_TABLE , values, KEY_TASK_ID + " = ?", new String[]{String.valueOf(task.get_id())});
        db.close();
    }

}


