package com.linearpractisefirstapp.todotoday;

/**
 * Created by Bilal on 1/4/2018.
 */
public class ToDo_Item {

    private int _id;
    private String description;
    private int is_done;

    ToDo_Item()
    {

    }
    ToDo_Item(int _id,String description,int is_done)
    {
       this._id=_id;
        this.description=description;
        this.is_done=is_done;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getIs_done() {
        return is_done;
    }

    public void setIs_done(int is_done) {
        this.is_done = is_done;
    }
}
